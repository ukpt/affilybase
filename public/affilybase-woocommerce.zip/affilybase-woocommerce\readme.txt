=== Affilybase for WooCommerce ===
Contributors: affilybase
Tags: affiliate, affiliation, woocommerce, marketing, commission
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Connect your WooCommerce store to Affilybase and manage your affiliate program automatically.

== Description ==

Affilybase for WooCommerce allows you to connect your WooCommerce store to your Affilybase affiliate program. Once installed, every sale made with an affiliate code is automatically detected and the commission is calculated instantly.

**How it works:**

1. Install the plugin and enter your Affilybase Vendor ID and Secret Key
2. Create affiliate codes in your Affilybase dashboard
3. Your affiliates share their codes on social media
4. When a customer orders using an affiliate code, the sale is automatically tracked
5. Commissions are calculated instantly in your Affilybase dashboard

**Key features:**

* Automatic sale tracking via WooCommerce order hooks
* Instant commission calculation
* Works with all WooCommerce compatible themes
* Simple setup — no coding required
* Compatible with Affilybase Free, Starter, Pro and Business plans
* 100% in French — designed for French online stores

**Requirements:**

* An active Affilybase account (free trial available at affilybase.com)
* WooCommerce 6.0 or higher
* WordPress 5.0 or higher

== Installation ==

1. Download the plugin ZIP file from affilybase.com
2. Go to WordPress Admin → Plugins → Add New → Upload Plugin
3. Upload the ZIP file and click "Install Now"
4. Activate the plugin
5. Go to the "Affilybase" menu in your WordPress admin
6. Enter your Vendor ID and Secret Key (available in your Affilybase dashboard under Settings → Integrations)
7. Copy the webhook URL and save your settings

== Frequently Asked Questions ==

= Do I need an Affilybase account? =

Yes, you need an active Affilybase account. You can start with a free 30-day trial at affilybase.com — no credit card required.

= Is the plugin free? =

Yes, the plugin is completely free. You only need an Affilybase subscription to use it.

= Which WooCommerce version is supported? =

The plugin is compatible with WooCommerce 6.0 and higher.

= How are commissions calculated? =

When a customer places an order using an affiliate coupon code, the plugin automatically sends the sale to Affilybase. The commission is calculated based on the percentage you set for each affiliate in your dashboard.

= Does it work with all payment gateways? =

Yes, the plugin works with all WooCommerce compatible payment gateways.

= Is it compatible with variable products? =

Yes, the plugin tracks all WooCommerce order types including variable products.

== Screenshots ==

1. Affilybase plugin settings page in WordPress admin
2. Affilybase dashboard showing WooCommerce sales
3. Affiliate management in Affilybase

== Changelog ==

= 1.0.0 =
* Initial release
* Automatic sale tracking via WooCommerce order hooks
* Commission calculation
* Simple settings page with Vendor ID and Secret Key

== Upgrade Notice ==

= 1.0.0 =
Initial release of Affilybase for WooCommerce.