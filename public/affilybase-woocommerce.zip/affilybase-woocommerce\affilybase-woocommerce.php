<?php
/**
 * Plugin Name: Affilybase for WooCommerce
 * Plugin URI: https://affilybase.com
 * Description: Connectez votre boutique WooCommerce à Affilybase et gérez votre programme d'affiliation automatiquement.
 * Version: 1.0.0
 * Author: Affilybase
 * Author URI: https://affilybase.com
 * License: GPL2
 * Text Domain: affilybase
 */

if (!defined('ABSPATH')) exit;

// Vérifier que WooCommerce est actif
add_action('plugins_loaded', 'affilybase_init');
function affilybase_init() {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function() {
            echo '<div class="error"><p>Affilybase nécessite WooCommerce pour fonctionner.</p></div>';
        });
        return;
    }
}

// Ajouter le menu dans WordPress admin
add_action('admin_menu', 'affilybase_menu');
function affilybase_menu() {
    add_menu_page(
        'Affilybase',
        'Affilybase',
        'manage_options',
        'affilybase',
        'affilybase_settings_page',
        'dashicons-store',
        56
    );
}

// Page de paramètres
function affilybase_settings_page() {
    if (isset($_POST['affilybase_save'])) {
        update_option('affilybase_vendeur_id', sanitize_text_field($_POST['affilybase_vendeur_id']));
        update_option('affilybase_webhook_secret', sanitize_text_field($_POST['affilybase_webhook_secret']));
        echo '<div class="updated"><p>Paramètres sauvegardés !</p></div>';
    }
    $vendeur_id = get_option('affilybase_vendeur_id', '');
    $webhook_secret = get_option('affilybase_webhook_secret', '');
    ?>
    <div class="wrap" style="font-family: sans-serif;">
        <div style="display:flex; align-items:center; gap:12px; margin-bottom:24px; padding-bottom:16px; border-bottom:1px solid #ddd;">
            <div style="font-size:28px; font-weight:700; color:#1a1a1a; font-family:Georgia,serif;">Affily<span style="font-size:12px; font-weight:400; color:#888; letter-spacing:0.2em; display:inline-block; margin-left:2px;">BASE</span></div>
        </div>

        <div style="background:#E1F5EE; border:0.5px solid #9FE1CB; border-radius:8px; padding:16px; margin-bottom:24px;">
            <div style="font-size:13px; font-weight:600; color:#085041; margin-bottom:4px;">✓ Plugin installé avec succès</div>
            <div style="font-size:12px; color:#0F6E56;">Connectez votre compte Affilybase pour activer le tracking automatique des ventes.</div>
        </div>

        <form method="post">
            <table class="form-table">
                <tr>
                    <th><label for="affilybase_vendeur_id">Votre ID Vendeur</label></th>
                    <td>
                        <input type="text" id="affilybase_vendeur_id" name="affilybase_vendeur_id" value="<?php echo esc_attr($vendeur_id); ?>" class="regular-text" placeholder="Trouvez votre ID dans Paramètres → Intégrations" />
                        <p class="description">Disponible dans votre tableau de bord Affilybase → Paramètres → Intégrations</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="affilybase_webhook_secret">Clé secrète</label></th>
                    <td>
                        <input type="text" id="affilybase_webhook_secret" name="affilybase_webhook_secret" value="<?php echo esc_attr($webhook_secret); ?>" class="regular-text" placeholder="Votre clé secrète Affilybase" />
                        <p class="description">Disponible dans votre tableau de bord Affilybase → Paramètres → Intégrations</p>
                    </td>
                </tr>
            </table>

            <div style="background:#fff; border:0.5px solid #ddd; border-radius:8px; padding:16px; margin:20px 0;">
                <div style="font-size:13px; font-weight:600; color:#1a1a1a; margin-bottom:8px;">URL de webhook à copier dans Affilybase :</div>
                <code style="background:#F5F2EC; padding:8px 12px; border-radius:4px; font-size:12px; display:block;"><?php echo home_url('/wp-json/affilybase/v1/webhook'); ?></code>
            </div>

            <p class="submit">
                <input type="submit" name="affilybase_save" class="button button-primary" value="Sauvegarder" style="background:#1a1a1a; border-color:#1a1a1a;" />
            </p>
        </form>
    </div>
    <?php
}

// REST API endpoint pour recevoir les commandes
add_action('rest_api_init', 'affilybase_register_routes');
function affilybase_register_routes() {
    register_rest_route('affilybase/v1', '/webhook', array(
        'methods' => 'POST',
        'callback' => 'affilybase_handle_webhook',
        'permission_callback' => '__return_true'
    ));
}

// Traitement du webhook entrant
function affilybase_handle_webhook($request) {
    $body = $request->get_json_params();
    return new WP_REST_Response(array('status' => 'ok'), 200);
}

// Détecter les commandes WooCommerce avec un code affilié
add_action('woocommerce_order_status_completed', 'affilybase_track_sale');
add_action('woocommerce_order_status_processing', 'affilybase_track_sale');

function affilybase_track_sale($order_id) {
    $vendeur_id = get_option('affilybase_vendeur_id', '');
    if (empty($vendeur_id)) return;

    $order = wc_get_order($order_id);
    if (!$order) return;

    // Récupérer le code coupon utilisé
    $coupons = $order->get_coupon_codes();
    if (empty($coupons)) return;

    $code = strtoupper($coupons[0]);
    $montant = $order->get_total();

    // Envoyer la vente à Affilybase
    $response = wp_remote_post('https://affilybase.com/api/woocommerce-sale', array(
        'method' => 'POST',
        'headers' => array(
            'Content-Type' => 'application/json',
            'X-Vendeur-ID' => $vendeur_id,
            'X-Secret' => get_option('affilybase_webhook_secret', '')
        ),
        'body' => json_encode(array(
            'code' => $code,
            'montant' => $montant,
            'order_id' => $order_id,
            'vendeur_id' => $vendeur_id
        )),
        'timeout' => 15
    ));
}

// Activation du plugin
register_activation_hook(__FILE__, 'affilybase_activate');
function affilybase_activate() {
    add_option('affilybase_vendeur_id', '');
    add_option('affilybase_webhook_secret', '');
}

// Désactivation du plugin
register_deactivation_hook(__FILE__, 'affilybase_deactivate');
function affilybase_deactivate() {
    // Nettoyage si nécessaire
}